CREATE DATABASE StudentDB;
USE StudentDB;


CREATE TABLE Students (
    StudentID INT PRIMARY KEY,
    StudentName VARCHAR(100) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    CourseName VARCHAR(50),
    ProgrammingScore DECIMAL(5,2)
        CHECK (ProgrammingScore BETWEEN 0 AND 100),
    MathematicsScore DECIMAL(5,2)
        CHECK (MathematicsScore BETWEEN 0 AND 100)
);

DESCRIBE Students;


CREATE TABLE TechnicalSkills (
    StudentID INT,
    SkillName VARCHAR(50),
    PRIMARY KEY (StudentID, SkillName),
    FOREIGN KEY (StudentID)
    REFERENCES Students(StudentID)
);
DESCRIBE TechnicalSkills;


INSERT INTO Students VALUES
(101, 'Aayush', 'aayush@gmail.com', 'CSIT', 90, 85),
(102, 'Rahul', 'rahul@gmail.com', 'CSE', 75, 80),
(103, 'Priya', 'priya@gmail.com', 'CSIT', 45, 90),
(104, 'Aman', 'aman@gmail.com', 'IT', 60, 65),
(105, 'Neha', 'neha@gmail.com', 'CSE', 40, 45);



INSERT INTO TechnicalSkills VALUES
(101, 'Java'),
(101, 'Python'),
(101, 'SQL'),
(102, 'Java'),
(102, 'Python'),
(103, 'Python'),
(103, 'SQL'),
(104, 'Java'),
(104, 'C++'),
(105, 'HTML'),
(105, 'CSS');
SELECT * FROM TechnicalSkills;



SELECT
    StudentID,
    StudentName,
    (ProgrammingScore + MathematicsScore) / 2 AS AverageScore
FROM Students;


SELECT
    StudentName,
    (ProgrammingScore + MathematicsScore) / 2 AS AverageScore,
    CASE
        WHEN (ProgrammingScore + MathematicsScore) / 2 >= 85
            THEN 'Excellent'
        WHEN (ProgrammingScore + MathematicsScore) / 2 >= 70
            THEN 'Good'
        WHEN (ProgrammingScore + MathematicsScore) / 2 >= 50
            THEN 'Satisfactory'
        ELSE 'Needs Improvement'
    END AS PerformanceCategory
FROM Students;


SELECT
    StudentName,
    CASE
        WHEN ProgrammingScore > MathematicsScore
            THEN 'Programming'
        WHEN MathematicsScore > ProgrammingScore
            THEN 'Mathematics'
        ELSE 'Both Equal'
    END AS StrongerSubject
FROM Students;


SELECT * FROM Students
WHERE StudentID = 101;

SELECT * FROM Students
WHERE Email = 'aayush@gmail.com';

SELECT * FROM Students
WHERE CourseName = 'CSIT';




SELECT
    s1.StudentName AS Student1,
    s2.StudentName AS Student2,
    t1.SkillName AS CommonSkill
FROM TechnicalSkills t1
JOIN TechnicalSkills t2
    ON t1.SkillName = t2.SkillName
    AND t1.StudentID < t2.StudentID
JOIN Students s1
    ON t1.StudentID = s1.StudentID
JOIN Students s2
    ON t2.StudentID = s2.StudentID;




INSERT INTO Students VALUES
(101, 'Test', 'test@gmail.com', 'CSIT', 80, 80);






