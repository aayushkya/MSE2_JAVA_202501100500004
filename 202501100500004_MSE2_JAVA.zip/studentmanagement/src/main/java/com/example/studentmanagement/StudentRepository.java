
package com.example.studentmanagement;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;

@Repository
public class StudentRepository {

    private final JdbcTemplate jdbc;

    public StudentRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    // 1. Add student
    @Transactional
    public String addStudent(Student s) {
        jdbc.update("INSERT INTO Students VALUES (?, ?, ?, ?, ?, ?)",
                s.getStudentID(), s.getStudentName(), s.getEmail(),
                s.getCourseName(), s.getProgrammingScore(),
                s.getMathematicsScore());

        if (s.getTechnicalSkills() != null) {
            for (String skill : s.getTechnicalSkills()) {
                jdbc.update("INSERT INTO TechnicalSkills VALUES (?, ?)",
                        s.getStudentID(), skill);
            }
        }
        return "Student added successfully";
    }

    // 2. Get all students
    public List<Student> getAllStudents() {
        List<Student> list = jdbc.query(
                "SELECT * FROM Students",
                (rs, rowNum) -> new Student(
                        rs.getInt("StudentID"),
                        rs.getString("StudentName"),
                        rs.getString("Email"),
                        rs.getString("CourseName"),
                        rs.getDouble("ProgrammingScore"),
                        rs.getDouble("MathematicsScore"),
                        getSkills(rs.getInt("StudentID"))
                ));
        return list;
    }

    // 3. Search student by ID
    public Student getStudentById(int id) {
        List<Student> list = jdbc.query(
                "SELECT * FROM Students WHERE StudentID = ?",
                (rs, rowNum) -> new Student(
                        rs.getInt("StudentID"),
                        rs.getString("StudentName"),
                        rs.getString("Email"),
                        rs.getString("CourseName"),
                        rs.getDouble("ProgrammingScore"),
                        rs.getDouble("MathematicsScore"),
                        getSkills(rs.getInt("StudentID"))
                ), id);

        return list.isEmpty() ? null : list.get(0);
    }

    // Get student's skills
    private List<String> getSkills(int id) {
        return jdbc.query(
                "SELECT SkillName FROM TechnicalSkills WHERE StudentID = ?",
                (rs, rowNum) -> rs.getString("SkillName"), id);
    }

    // 4. Update scores and skills
    @Transactional
    public String updateStudent(int id, Student s) {
        int rows = jdbc.update(
                "UPDATE Students SET ProgrammingScore=?, MathematicsScore=? WHERE StudentID=?",
                s.getProgrammingScore(), s.getMathematicsScore(), id);

        if (rows == 0) return "Student not found";

        jdbc.update("DELETE FROM TechnicalSkills WHERE StudentID=?", id);

        if (s.getTechnicalSkills() != null) {
            for (String skill : s.getTechnicalSkills()) {
                jdbc.update("INSERT INTO TechnicalSkills VALUES (?, ?)", id, skill);
            }
        }
        return "Student scores and skills updated successfully";
    }

    // 5. Delete student
    @Transactional
    public String deleteStudent(int id) {
        jdbc.update("DELETE FROM TechnicalSkills WHERE StudentID=?", id);
        int rows = jdbc.update("DELETE FROM Students WHERE StudentID=?", id);
        return rows > 0 ? "Student deleted successfully" : "Student not found";
    }

    // 6. Merit list
    public List<Map<String, Object>> getMeritList() {
        return jdbc.queryForList(
                "SELECT StudentID, StudentName, ProgrammingScore, MathematicsScore, " +
                        "(ProgrammingScore + MathematicsScore)/2 AS AverageScore " +
                        "FROM Students ORDER BY AverageScore DESC");
    }
}
