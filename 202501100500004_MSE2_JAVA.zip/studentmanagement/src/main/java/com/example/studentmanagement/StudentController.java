
package com.example.studentmanagement;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    private final StudentRepository repo;

    public StudentController(StudentRepository repo) {
        this.repo = repo;
    }

    // 1. Add student
    @PostMapping
    public String addStudent(@RequestBody Student student) {
        return repo.addStudent(student);
    }

    // 2. Retrieve all students
    @GetMapping
    public List<Student> getAllStudents() {
        return repo.getAllStudents();
    }

    // 3. Search student by ID
    @GetMapping("/{id}")
    public Student getStudentById(@PathVariable int id) {
        return repo.getStudentById(id);
    }

    // 4. Update scores and skills
    @PutMapping("/{id}")
    public String updateStudent(@PathVariable int id,
                                @RequestBody Student student) {
        return repo.updateStudent(id, student);
    }

    // 5. Delete student
    @DeleteMapping("/{id}")
    public String deleteStudent(@PathVariable int id) {
        return repo.deleteStudent(id);
    }

    // 6. Merit list
    @GetMapping("/merit")
    public List<Map<String, Object>> getMeritList() {
        return repo.getMeritList();
    }
}
