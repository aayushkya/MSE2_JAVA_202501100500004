
import java.util.*;

class Student {

    // 1. Private attributes (Encapsulation)
    private int studentID;
    private String studentName;
    private String email;
    private String courseName;
    private double programmingScore;
    private double mathematicsScore;
    private ArrayList<String> technicalSkills;

    // 2. Constructor
    public Student(int studentID, String studentName,
                   String email, String courseName,
                   double programmingScore, double mathematicsScore,
                   ArrayList<String> technicalSkills) {

        this.studentID = studentID;
        this.studentName = studentName;
        this.email = email;
        this.courseName = courseName;
        this.programmingScore = programmingScore;
        this.mathematicsScore = mathematicsScore;
        this.technicalSkills = technicalSkills;
    }

    // 3. Getters
    public int getStudentID() {
        return studentID;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getEmail() {
        return email;
    }

    public String getCourseName() {
        return courseName;
    }

    public double getProgrammingScore() {
        return programmingScore;
    }

    public double getMathematicsScore() {
        return mathematicsScore;
    }

    public ArrayList<String> getTechnicalSkills() {
        return technicalSkills;
    }

    // 4. Setters
    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public void setProgrammingScore(double score) {
        this.programmingScore = score;
    }

    public void setMathematicsScore(double score) {
        this.mathematicsScore = score;
    }

    public void setTechnicalSkills(ArrayList<String> skills) {
        this.technicalSkills = skills;
    }

    // 5. Object methods
    public double calculateAverage() {
        return (programmingScore + mathematicsScore) / 2;
    }

    public void displayDetails() {
        System.out.println("Student ID: " + studentID);
        System.out.println("Name: " + studentName);
        System.out.println("Email: " + email);
        System.out.println("Course: " + courseName);
        System.out.println("Programming Score: " + programmingScore);
        System.out.println("Mathematics Score: " + mathematicsScore);
        System.out.println("Technical Skills: " + technicalSkills);
        System.out.println("Average Score: " + calculateAverage());
    }
}

// Main class
public class Main {
    public static void main(String[] args) {

        ArrayList<String> skills = new ArrayList<>();
        skills.add("Java");
        skills.add("Python");
        skills.add("SQL");

        Student s1 = new Student(
                101, "Aayush", "aayush@gmail.com",
                "CSIT", 85, 90, skills
        );

        s1.displayDetails();

        // Using setter
        s1.setProgrammingScore(95);

        System.out.println("\nAfter Updating Score:");
        s1.displayDetails();
    }
}
